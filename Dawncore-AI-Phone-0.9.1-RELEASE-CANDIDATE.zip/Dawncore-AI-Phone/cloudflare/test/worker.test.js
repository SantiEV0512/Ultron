import test from 'node:test';
import assert from 'node:assert/strict';
import worker from '../src/index.js';

const DEVICE = 'd'.repeat(40);
const contacts = JSON.stringify([
  { alias: 'santi', phone: '5215512345678', email: 'santi@example.com' }
]);
const envBase = { DEVICE_TOKEN: DEVICE, ADMIN_TOKEN: 'a'.repeat(40), ALLOWED_CONTACTS_JSON: contacts };
const req = (path, { method = 'GET', token = DEVICE, body, headers = {} } = {}) => new Request('https://worker.test' + path, {
  method,
  headers: { ...(token ? { authorization: `Bearer ${token}` } : {}), ...(body !== undefined ? { 'content-type': 'application/json' } : {}), ...headers },
  body: body === undefined ? undefined : JSON.stringify(body)
});
const json = async response => ({ status: response.status, body: await response.json() });

test('health reports 0.9.1 without authentication', async () => {
  const result = await json(await worker.fetch(req('/health', { token: '' }), envBase));
  assert.equal(result.status, 200);
  assert.equal(result.body.api, '0.9.1');
});

test('assistant endpoints reject missing/invalid device credentials', async () => {
  const result = await json(await worker.fetch(req('/assistant/llm', { token: '', method: 'POST', body: { prompt: 'hola' } }), envBase));
  assert.equal(result.status, 401);
});

test('WhatsApp refuses a recipient outside the server allowlist', async () => {
  const result = await json(await worker.fetch(req('/assistant/whatsapp', { method: 'POST', body: { alias: 'intruso', phone: '5215512345678', message: 'hola' } }), envBase));
  assert.equal(result.status, 403);
  assert.equal(result.body.error, 'recipient_not_allowed');
});

test('WhatsApp requires exact allowlisted phone and configured provider', async () => {
  const mismatch = await json(await worker.fetch(req('/assistant/whatsapp', { method: 'POST', body: { alias: 'santi', phone: '5215500000000', message: 'hola' } }), envBase));
  assert.equal(mismatch.status, 400);
  const missing = await json(await worker.fetch(req('/assistant/whatsapp', { method: 'POST', body: { alias: 'santi', phone: '5215512345678', message: 'hola' } }), envBase));
  assert.equal(missing.status, 503);
  assert.equal(missing.body.error, 'whatsapp_not_configured');
});

test('WhatsApp sends only to the exact allowlisted number', async t => {
  const original = globalThis.fetch;
  t.after(() => { globalThis.fetch = original; });
  let sent;
  globalThis.fetch = async (url, options) => {
    sent = { url: String(url), body: JSON.parse(options.body) };
    return Response.json({ messages: [{ id: 'wamid.test' }] });
  };
  const env = { ...envBase, WHATSAPP_TOKEN: 'test-token', WHATSAPP_PHONE_NUMBER_ID: '123', WHATSAPP_API_VERSION: 'v99.0' };
  const result = await json(await worker.fetch(req('/assistant/whatsapp', { method: 'POST', body: { alias: 'santi', phone: '+52 155 1234 5678', message: 'Hola' } }), env));
  assert.equal(result.status, 200);
  assert.equal(result.body.sent, true);
  assert.equal(sent.body.to, '5215512345678');
  assert.equal(sent.body.text.body, 'Hola');
});

test('Gmail validates recipient and sends UTF-8 MIME through OAuth', async t => {
  const original = globalThis.fetch;
  t.after(() => { globalThis.fetch = original; });
  const calls = [];
  globalThis.fetch = async (url, options) => {
    calls.push({ url: String(url), options });
    if (String(url).includes('oauth2.googleapis.com')) return Response.json({ access_token: 'access-test' });
    const payload = JSON.parse(options.body);
    const raw = payload.raw.replace(/-/g, '+').replace(/_/g, '/');
    const mime = Buffer.from(raw, 'base64').toString('utf8');
    assert.match(mime, /Subject: =\?UTF-8\?B\?/);
    assert.match(mime, /café/);
    assert.match(mime, /To: santi@example.com/);
    return Response.json({ id: 'gmail-message-id' });
  };
  const env = { ...envBase, GOOGLE_CLIENT_ID: 'id', GOOGLE_CLIENT_SECRET: 'secret', GOOGLE_REFRESH_TOKEN: 'refresh', GMAIL_SENDER: 'owner@example.com' };
  const result = await json(await worker.fetch(req('/assistant/gmail', { method: 'POST', body: { alias: 'santi', email: 'santi@example.com', subject: 'Aviso café', body: 'Hola, café listo.' } }), env));
  assert.equal(result.status, 200);
  assert.equal(result.body.sent, true);
  assert.equal(calls.length, 2);
});

test('Gmail rejects header injection and mismatched recipient', async t => {
  const original = globalThis.fetch;
  t.after(() => { globalThis.fetch = original; });
  const env = { ...envBase, GOOGLE_CLIENT_ID: 'id', GOOGLE_CLIENT_SECRET: 'secret', GOOGLE_REFRESH_TOKEN: 'refresh', GMAIL_SENDER: 'owner@example.com' };
  const mismatch = await json(await worker.fetch(req('/assistant/gmail', { method: 'POST', body: { alias: 'santi', email: 'other@example.com', subject: 'Hi', body: 'Hola' } }), env));
  assert.equal(mismatch.status, 400);
  let mimeText = '';
  globalThis.fetch = async (url, options) => {
    if (String(url).includes('oauth2.googleapis.com')) return Response.json({ access_token: 'access-test' });
    const raw = JSON.parse(options.body).raw.replace(/-/g, '+').replace(/_/g, '/');
    mimeText = Buffer.from(raw, 'base64').toString('utf8');
    return Response.json({ id: 'gmail-message-id' });
  };
  const injected = await json(await worker.fetch(req('/assistant/gmail', { method: 'POST', body: { alias: 'santi', email: 'santi@example.com', subject: 'Hola\r\nBcc: attacker@example.com', body: 'Hola' } }), env));
  assert.equal(injected.status, 200);
  assert.doesNotMatch(mimeText, /\r\nBcc:/i);
});

test('malformed and duplicate allowlists fail closed', async () => {
  const malformed = { ...envBase, ALLOWED_CONTACTS_JSON: '{bad' };
  const a = await json(await worker.fetch(req('/assistant/gmail', { method: 'POST', body: { alias: 'santi', email: 'santi@example.com', subject: 'x', body: 'y' } }), malformed));
  assert.equal(a.status, 503);
  const duplicate = { ...envBase, ALLOWED_CONTACTS_JSON: JSON.stringify([{ alias: 'santi', phone: '5215512345678' }, { alias: 'santi', email: 'santi@example.com' }]) };
  const b = await json(await worker.fetch(req('/assistant/whatsapp', { method: 'POST', body: { alias: 'santi', phone: '5215512345678', message: 'hi' } }), duplicate));
  assert.equal(b.status, 503);
});

test('voice proxy returns audio bytes and never requires an allowlist alias', async t => {
  const original = globalThis.fetch;
  t.after(() => { globalThis.fetch = original; });
  globalThis.fetch = async () => new Response(new Uint8Array([1, 2, 3]), { headers: { 'content-type': 'audio/mpeg' } });
  const env = { ...envBase, ALLOWED_CONTACTS_JSON: 'invalid-but-irrelevant', FISH_AUDIO_API_KEY: 'fish-test', FISH_AUDIO_REFERENCE_ID: 'voice-id' };
  const response = await worker.fetch(req('/assistant/voice', { method: 'POST', body: { text: 'Hola' } }), env);
  assert.equal(response.status, 200);
  assert.equal(response.headers.get('content-type'), 'audio/mpeg');
  assert.deepEqual([...new Uint8Array(await response.arrayBuffer())], [1, 2, 3]);
});

test('LLM proxy enforces prompt size and returns structured model output', async t => {
  const original = globalThis.fetch;
  t.after(() => { globalThis.fetch = original; });
  let requestBody;
  globalThis.fetch = async (_url, options) => {
    requestBody = JSON.parse(options.body);
    return Response.json({ choices: [{ message: { content: '{"action":"unknown","alias":"","message":"","subject":"","body":""}' } }] });
  };
  const env = { ...envBase, GROQ_API_KEY: 'groq-test' };
  const tooLong = await json(await worker.fetch(req('/assistant/llm', { method: 'POST', body: { prompt: 'x'.repeat(5000) } }), env));
  assert.equal(tooLong.status, 400); // oversized prompts are rejected, never silently truncated.
  assert.equal(requestBody, undefined); // oversized prompt was rejected before contacting Groq.
});

test('LLM accepts bounded prompt and requests JSON mode', async t => {
  const original = globalThis.fetch;
  t.after(() => { globalThis.fetch = original; });
  let requestBody;
  globalThis.fetch = async (_url, options) => {
    requestBody = JSON.parse(options.body);
    return Response.json({ choices: [{ message: { content: '{\"action\":\"unknown\",\"alias\":\"\",\"message\":\"\",\"subject\":\"\",\"body\":\"\"}' } }] });
  };
  const env = { ...envBase, GROQ_API_KEY: 'groq-test' };
  const result = await json(await worker.fetch(req('/assistant/llm', { method: 'POST', body: { prompt: 'interpreta esta orden' } }), env));
  assert.equal(result.status, 200);
  assert.equal(requestBody.response_format.type, 'json_object');
});
