const json = (data, status = 200, headers = {}) => new Response(JSON.stringify(data), {
  status,
  headers: {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff',
    'referrer-policy': 'no-referrer',
    ...headers
  }
});
const safeEq = (a, b) => {
  if (typeof a !== 'string' || typeof b !== 'string' || !a || !b || a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
};
const bearer = req => {
  const value = req.headers.get('authorization') || '';
  const match = /^Bearer\s+(.+)$/i.exec(value);
  return match ? match[1].trim() : '';
};
const validDevice = value => typeof value === 'string' && /^[a-f0-9]{32}$/i.test(value);
const randomId = () => crypto.randomUUID();
const trimText = value => typeof value === 'string' ? value.trim() : '';
const digits = value => String(value || '').replace(/\D/g, '');
const validEmail = value => typeof value === 'string' && value.length <= 254 && /^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(value);
const reply = (req, env, data, status = 200) => {
  const origin = req.headers.get('Origin');
  const headers = {};
  if (origin && env.ADMIN_WEB_ORIGIN && origin === env.ADMIN_WEB_ORIGIN) {
    headers['access-control-allow-origin'] = origin;
    headers['vary'] = 'Origin';
    headers['access-control-allow-methods'] = 'GET, POST, OPTIONS';
    headers['access-control-allow-headers'] = 'authorization, content-type';
    headers['access-control-max-age'] = '600';
  }
  return json(data, status, headers);
};
const readJson = async req => {
  const length = Number(req.headers.get('content-length') || 0);
  if (length > 30000) throw new Error('body_too_large');
  const value = await req.json();
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('invalid_json');
  return value;
};
const loadAllowlist = env => {
  let entries;
  try { entries = JSON.parse(env.ALLOWED_CONTACTS_JSON || '[]'); }
  catch { throw new Error('allowlist_misconfigured'); }
  if (!Array.isArray(entries)) throw new Error('allowlist_misconfigured');
  const normalized = [];
  const aliases = new Set();
  for (const entry of entries) {
    if (!entry || typeof entry !== 'object') throw new Error('allowlist_misconfigured');
    const alias = trimText(entry.alias).toLowerCase();
    const phone = digits(entry.phone);
    const email = trimText(entry.email).toLowerCase();
    if (!/^[a-z0-9_-]{1,40}$/.test(alias) || aliases.has(alias) || (!phone && !email) || (phone && !/^\d{8,15}$/.test(phone)) || (email && !validEmail(email)))
      throw new Error('allowlist_misconfigured');
    aliases.add(alias);
    normalized.push({ alias, phone, email });
  }
  return normalized;
};
const toBase64UrlUtf8 = value => {
  const bytes = new TextEncoder().encode(value);
  let binary = '';
  for (let i = 0; i < bytes.length; i += 0x8000) {
    binary += String.fromCharCode(...bytes.subarray(i, Math.min(i + 0x8000, bytes.length)));
  }
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
};
const providerError = (req, env, provider, status) => reply(req, env, {
  error: provider + '_provider_error', providerStatus: status
}, 502);

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    const method = req.method;

    if (method === 'OPTIONS') {
      const origin = req.headers.get('Origin');
      if (!origin || !env.ADMIN_WEB_ORIGIN || origin !== env.ADMIN_WEB_ORIGIN)
        return new Response(null, { status: 403, headers: { 'cache-control': 'no-store' } });
      return new Response(null, { status: 204, headers: {
        'access-control-allow-origin': origin,
        'access-control-allow-methods': 'GET, POST, OPTIONS',
        'access-control-allow-headers': 'authorization, content-type',
        'access-control-max-age': '600', 'vary': 'Origin', 'cache-control': 'no-store'
      }});
    }

    if (method === 'GET' && url.pathname === '/health')
      return reply(req, env, { service: 'Dawncore ULTRÓN Cloud', status: 'online', api: '0.9.1' });

    if (method === 'POST' && url.pathname === '/admin/command') {
      if (!safeEq(bearer(req), env.ADMIN_TOKEN)) return reply(req, env, { error: 'unauthorized' }, 401);
      let body;
      try { body = await readJson(req); } catch (e) { return reply(req, env, { error: e.message }, 400); }
      if (!['LOCK', 'UNLOCK'].includes(body.action) || !validDevice(body.deviceId))
        return reply(req, env, { error: 'invalid_request' }, 400);
      const reason = trimText(body.reason || 'Orden administrativa').replace(/[\u0000-\u001f\u007f]/g, ' ').slice(0, 160);
      const now = Math.floor(Date.now() / 1000);
      const commandId = randomId();
      await env.DB.prepare('INSERT INTO commands(id,device_id,action,reason,created_at,expires_at) VALUES(?,?,?,?,?,?)')
        .bind(commandId, body.deviceId, body.action, reason, now, now + 300).run();
      return reply(req, env, { accepted: true, commandId, expiresAt: now + 300, state: 'QUEUED' });
    }

    if (method === 'GET' && url.pathname === '/device/command') {
      if (!safeEq(bearer(req), env.DEVICE_TOKEN)) return reply(req, env, { error: 'unauthorized' }, 401);
      const deviceId = url.searchParams.get('deviceId') || '';
      if (!validDevice(deviceId)) return reply(req, env, { error: 'invalid_device' }, 400);
      const now = Math.floor(Date.now() / 1000);
      // A command is leased for 30 seconds and re-delivered if the device crashes before ack.
      const row = await env.DB.prepare(
        'SELECT id,action,reason,created_at,expires_at FROM commands WHERE device_id=? AND ack_at IS NULL AND expires_at>? AND (consumed_at IS NULL OR consumed_at<=?) ORDER BY created_at ASC LIMIT 1'
      ).bind(deviceId, now, now - 30).first();
      if (!row) return reply(req, env, { command: null });
      const update = await env.DB.prepare('UPDATE commands SET consumed_at=? WHERE id=? AND ack_at IS NULL AND (consumed_at IS NULL OR consumed_at<=?)')
        .bind(now, row.id, now - 30).run();
      if (update.meta && update.meta.changes === 0) return reply(req, env, { command: null });
      return reply(req, env, { command: row });
    }

    if (method === 'POST' && url.pathname === '/device/ack') {
      if (!safeEq(bearer(req), env.DEVICE_TOKEN)) return reply(req, env, { error: 'unauthorized' }, 401);
      let body;
      try { body = await readJson(req); } catch (e) { return reply(req, env, { error: e.message }, 400); }
      if (!validDevice(body.deviceId) || typeof body.commandId !== 'string' || body.commandId.length > 64 ||
          typeof body.result !== 'string' || !/^[A-Z_]{2,40}$/.test(body.result))
        return reply(req, env, { error: 'invalid_request' }, 400);
      const now = Math.floor(Date.now() / 1000);
      const result = await env.DB.prepare(
        'UPDATE commands SET ack_at=?,ack_result=? WHERE id=? AND device_id=? AND consumed_at IS NOT NULL AND ack_at IS NULL'
      ).bind(now, body.result, body.commandId, body.deviceId).run();
      return reply(req, env, { acknowledged: !!(result.meta && result.meta.changes > 0) });
    }

    if (method === 'GET' && url.pathname === '/admin/status') {
      if (!safeEq(bearer(req), env.ADMIN_TOKEN)) return reply(req, env, { error: 'unauthorized' }, 401);
      const deviceId = url.searchParams.get('deviceId') || '';
      if (!validDevice(deviceId)) return reply(req, env, { error: 'invalid_device' }, 400);
      const row = await env.DB.prepare(
        'SELECT id,action,reason,created_at,expires_at,consumed_at,ack_at,ack_result FROM commands WHERE device_id=? ORDER BY created_at DESC LIMIT 1'
      ).bind(deviceId).first();
      return reply(req, env, { deviceId, lastCommand: row || null });
    }

    const deviceAuthed = safeEq(bearer(req), env.DEVICE_TOKEN);
    const assistantRoutes = ['/assistant/whatsapp', '/assistant/gmail', '/assistant/llm', '/assistant/voice'];
    if (method === 'POST' && assistantRoutes.includes(url.pathname)) {
      if (!deviceAuthed) return reply(req, env, { error: 'unauthorized' }, 401);
      let body;
      try { body = await readJson(req); } catch (e) { return reply(req, env, { error: e.message }, 400); }

      if (url.pathname === '/assistant/llm') {
        if (!env.GROQ_API_KEY) return reply(req, env, { error: 'groq_not_configured' }, 503);
        const prompt = trimText(body.prompt);
        if (!prompt || prompt.length > 4000) return reply(req, env, { error: 'prompt_required' }, 400);
        const r = await fetch('https://api.groq.com/openai/v1/chat/completions', {
          method: 'POST', headers: { authorization: `Bearer ${env.GROQ_API_KEY}`, 'content-type': 'application/json' },
          body: JSON.stringify({ model: env.GROQ_MODEL || 'openai/gpt-oss-120b', temperature: 0,
            response_format: { type: 'json_object' },
            messages: [
              { role: 'system', content: 'Devuelve SOLO un objeto JSON válido con action, alias, message, subject, body. action debe ser call, whatsapp, email o unknown. alias debe ser un alias literal mencionado por el usuario; no inventes alias, teléfono ni correo. No envíes nada ni afirmes que una acción ya se realizó. El servidor y la app validan la lista permitida.' },
              { role: 'user', content: prompt }
            ] })
        });
        const data = await r.json().catch(() => ({}));
        if (!r.ok) return providerError(req, env, 'groq', r.status);
        return reply(req, env, { content: data.choices?.[0]?.message?.content || '' });
      }

      if (url.pathname === '/assistant/voice') {
        const text = trimText(body.text);
        if (!text || text.length > 1200) return reply(req, env, { error: 'text_invalid' }, 400);
        if (!env.FISH_AUDIO_API_KEY || !env.FISH_AUDIO_REFERENCE_ID)
          return reply(req, env, { error: 'fish_audio_not_configured' }, 503);
        const speech = await fetch('https://api.fish.audio/v1/tts', {
          method: 'POST', headers: { authorization: `Bearer ${env.FISH_AUDIO_API_KEY}`, 'content-type': 'application/json', 'model': env.FISH_AUDIO_MODEL || 's2.1' },
          body: JSON.stringify({ text, reference_id: env.FISH_AUDIO_REFERENCE_ID, format: 'mp3' })
        });
        if (!speech.ok) return providerError(req, env, 'fish_audio', speech.status);
        return new Response(await speech.arrayBuffer(), { status: 200, headers: {
          'content-type': 'audio/mpeg', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff'
        }});
      }

      let recipient;
      try {
        const alias = trimText(body.alias, 40).toLowerCase();
        recipient = loadAllowlist(env).find(x => x.alias === alias);
      } catch (e) { return reply(req, env, { error: e.message }, 503); }
      if (!recipient) return reply(req, env, { error: 'recipient_not_allowed' }, 403);

      if (url.pathname === '/assistant/whatsapp') {
        const phone = digits(body.phone);
        const message = trimText(body.message);
        if (message.length > 4000 || !recipient.phone || !phone || phone !== recipient.phone || !message)
          return reply(req, env, { error: 'recipient_or_message_invalid' }, 400);
        if (!env.WHATSAPP_TOKEN || !env.WHATSAPP_PHONE_NUMBER_ID || !env.WHATSAPP_API_VERSION)
          return reply(req, env, { error: 'whatsapp_not_configured' }, 503);
        const wa = await fetch(`https://graph.facebook.com/${env.WHATSAPP_API_VERSION}/${env.WHATSAPP_PHONE_NUMBER_ID}/messages`, {
          method: 'POST', headers: { authorization: `Bearer ${env.WHATSAPP_TOKEN}`, 'content-type': 'application/json' },
          body: JSON.stringify({ messaging_product: 'whatsapp', recipient_type: 'individual', to: phone, type: 'text', text: { preview_url: false, body: message } })
        });
        const result = await wa.json().catch(() => ({}));
        if (!wa.ok) return providerError(req, env, 'whatsapp', wa.status);
        return reply(req, env, { sent: true, message: 'WhatsApp aceptó el mensaje para envío.', providerMessageId: result.messages?.[0]?.id || null });
      }

      if (url.pathname === '/assistant/gmail') {
        const to = trimText(body.email).toLowerCase();
        const subject = trimText(body.subject).replace(/[\r\n]/g, ' ');
        const message = trimText(body.body);
        const sender = trimText(env.GMAIL_SENDER, 254);
        if (!recipient.email || !validEmail(to) || to !== recipient.email || !subject || subject.length > 200 || !message || message.length > 20000 || !validEmail(sender))
          return reply(req, env, { error: 'recipient_or_message_invalid' }, 400);
        const required = ['GOOGLE_CLIENT_ID', 'GOOGLE_CLIENT_SECRET', 'GOOGLE_REFRESH_TOKEN', 'GMAIL_SENDER'];
        if (required.some(k => !env[k])) return reply(req, env, { error: 'gmail_not_configured' }, 503);
        const tokenResp = await fetch('https://oauth2.googleapis.com/token', {
          method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams({ client_id: env.GOOGLE_CLIENT_ID, client_secret: env.GOOGLE_CLIENT_SECRET,
            refresh_token: env.GOOGLE_REFRESH_TOKEN, grant_type: 'refresh_token' })
        });
        const tokenData = await tokenResp.json().catch(() => ({}));
        if (!tokenResp.ok || !tokenData.access_token) return providerError(req, env, 'gmail_oauth', tokenResp.status);
        const encodedSubject = `=?UTF-8?B?${btoa(unescape(encodeURIComponent(subject)))}?=`;
        const mime = `To: ${to}\r\nFrom: ${sender}\r\nSubject: ${encodedSubject}\r\nMIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n\r\n${message}`;
        const raw = toBase64UrlUtf8(mime);
        const sent = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
          method: 'POST', headers: { authorization: `Bearer ${tokenData.access_token}`, 'content-type': 'application/json' },
          body: JSON.stringify({ raw })
        });
        const sentData = await sent.json().catch(() => ({}));
        if (!sent.ok) return providerError(req, env, 'gmail', sent.status);
        return reply(req, env, { sent: true, message: 'Gmail aceptó el correo para envío.', providerMessageId: sentData.id || null });
      }
    }

    return reply(req, env, { error: 'not_found' }, 404);
  }
};
