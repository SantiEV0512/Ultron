CREATE TABLE IF NOT EXISTS commands (
  id TEXT PRIMARY KEY,
  device_id TEXT NOT NULL,
  action TEXT NOT NULL CHECK(action IN ('LOCK','UNLOCK')),
  reason TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  consumed_at INTEGER,
  ack_at INTEGER,
  ack_result TEXT
);
CREATE INDEX IF NOT EXISTS idx_commands_device_pending ON commands(device_id, consumed_at, created_at);
