#!/usr/bin/env bash
set -euo pipefail
if grep -q 'android.permission.SEND_SMS' app/src/main/AndroidManifest.xml; then
  echo 'ERROR: ULTRÓN must not request SMS permission.' >&2
  exit 1
fi
if grep -R -E 'GROQ_API_KEY|FISH_AUDIO_API_KEY|WHATSAPP_TOKEN|GOOGLE_CLIENT_SECRET' app/src/main; then
  echo 'ERROR: Provider secret names/values must not be embedded in Android source.' >&2
  exit 1
fi
echo 'Security source checks passed.'
