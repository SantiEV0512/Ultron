# Changelog

## 0.8.3 — Evolution Lab + Remote Command Bridge
- Added a bounded local observation store and a human-review proposal queue.
- Evolution Lab is intentionally non-executable: no shell, dynamic code loading, app-code mutation, package installation, policy editing, PIN access, or RED LINE bypass.
- Added Android Keystore AES-GCM encryption for the remote device token.
- Added a random per-install device ID; no IMEI is used.
- Added on-demand HTTPS polling from the Android app and command acknowledgements to Cloudflare Worker/D1.
- Remote LOCK activates the local in-app RED LINE screen. Remote UNLOCK never bypasses the local PIN.
- Added command acknowledgement/status fields to D1 and the admin status endpoint.
- Updated app version and CI artifact naming to 0.8.3.

## Known limitations
- Polling is manual/on-demand; there is no persistent background service or guaranteed remote delivery.
- The Worker still uses one shared DEVICE_TOKEN secret. Production requires per-device enrollment, credentials, rotation/revocation and stronger admin authentication.
- RED LINE is an in-app lock, not a whole-Android lock or anti-uninstall protection. Device Owner is not enabled; no factory reset is performed.
- Evolution stores observations/proposals only; it does not autonomously generate, compile, or install code.
- Source archive only: no successful APK build or physical LG test is claimed. Run GitHub Actions and the test plan before installing.

## 0.9.0 — Cloud messaging, Fish Audio and safer policy

- Added Worker-side WhatsApp Business Cloud API sending with exact server-side allowlist matching.
- Added Gmail API sending using OAuth refresh credentials held as Cloudflare secrets.
- Moved Groq interpretation to the Cloudflare Worker; the Android UI no longer accepts/stores a provider API key.
- Added Fish Audio TTS proxy and MP3 playback, retaining Android TTS as fallback.
- WhatsApp/Gmail sends occur after an explicit user command to an authorized contact; no SMS permission or SMS feature.
- Unknown recipients are denied and audited without triggering a false emergency RED LINE lock.
- Rechecks local recipient identity and RED LINE before executing actions; call permission callback revalidates the state.
- Added null-safe notification extras handling and setup/test documentation.
- Self-evolution remains a proposal/staging design, not unrestricted production self-modification.


## 0.9.1 — Hardening + release candidate
- Reworked Cloudflare Worker request validation: rejects oversized/malformed bodies, malformed or duplicate allowlists, mismatched recipients, invalid email addresses and unsafe headers.
- Removed the allowlist dependency from Groq/Fish Audio routes; those services no longer fail merely because the contacts JSON is invalid.
- Gmail MIME is encoded as UTF-8/base64url without spreading large buffers into function arguments.
- Groq requests use JSON mode and reject oversized prompts instead of silently truncating them. Replaced the retired Llama 3.3 model with Groq's recommended `openai/gpt-oss-120b`.
- Remote commands use a 30-second lease and can be re-delivered if the phone crashes before acknowledgement.
- Android HTTPS client rejects non-HTTPS URLs, userinfo/query/fragment URLs, unexpected routes and redirects; handles empty/non-JSON error bodies and plays Fish Audio asynchronously.
- Added 10 automated Cloudflare Worker tests and CI checks before Android build.
- Pinned WhatsApp Graph API to v27.0 (review again before future upgrades).

## 0.9.1 known limitations
- Source-only release candidate. No APK build or physical LG test is claimed from this environment.
- WhatsApp integration is Business Cloud API only; free-form text is subject to Meta's customer-service window and approved-template rules. Template messages are not implemented.
- OAuth/Cloudflare/Meta/Fish Audio credentials and contact allowlist must be configured by the account owner.
- Remote command polling remains manual. Per-device token enrollment, full admin MFA, and autonomous signed patch promotion are not implemented.
