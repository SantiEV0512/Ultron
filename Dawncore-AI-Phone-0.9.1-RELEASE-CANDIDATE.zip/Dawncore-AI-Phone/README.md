# Dawncore AI Phone — ULTRÓN 0.9.1

Android Java project targeting Android 6.0+ (minSdk 23).

## Base features (0.8.3)
- On-demand remote RED LINE command polling and acknowledgements.
- Remote token encrypted at rest with Android Keystore AES-GCM.
- Random installation device ID; no IMEI.
- ULTRÓN Evolution Lab for bounded local observations and human-reviewed improvement proposals.

## Remote administration setup
Configure Worker secrets `ADMIN_TOKEN` and `DEVICE_TOKEN` (independent random values, at least 32 characters) and set `ADMIN_WEB_ORIGIN` to the exact HTTPS origin hosting the admin panel. See `docs/REMOTE_ADMIN_0.8.3.md`.

## Build
Run **Actions → Build Dawncore AI Phone APK → Run workflow** in GitHub. CI uses JDK 17, Android SDK 35 and Gradle 8.7. The output is a debug APK.

## Security boundaries
The LLM is untrusted input and cannot authorize actions, alter RED LINE, read the PIN, edit the allowlist, or approve its own changes. Evolution Lab stores proposals only. It cannot execute shell commands or modify installed app code.

Remote LOCK applies locally after an authenticated HTTPS poll. Remote UNLOCK is only a request; the local administrator PIN is still required.

## Limitations
- RED LINE is an in-app lock, not a whole-device lock.
- Device Owner provisioning is not enabled. Android Device Owner normally requires provisioning on a new/reset device; this release does not reset the LG.
- Offline, powered-off, force-stopped, or non-polling phones cannot receive remote commands.
- Worker uses a shared DEVICE_TOKEN prototype; do not treat it as production-grade per-device isolation.
- This is source code, not a verified APK. Run CI and test on a spare device before relying on it.


## Versión 0.9.1

Consulta [`docs/SETUP_0.9.1.md`](docs/SETUP_0.9.1.md) para configurar WhatsApp Business Cloud API, Gmail OAuth, Groq y Fish Audio mediante Cloudflare Worker. No se incluyen claves API en el repositorio. La APK aún requiere compilación y prueba en el dispositivo LG Android 6. Consulta `docs/SETUP_0.9.1.md` y ejecuta las pruebas del Worker con `cd cloudflare && npm test`.
