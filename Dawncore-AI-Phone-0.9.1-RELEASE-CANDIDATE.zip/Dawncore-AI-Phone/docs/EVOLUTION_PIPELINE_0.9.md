# ULTRÓN Evolution Pipeline — política 0.9

ULTRÓN puede analizar errores, proponer cambios y generar parches dentro de un entorno de staging aislado. El proceso de publicación se mantiene fuera de su autoridad.

## Zonas de confianza

1. **Producción (LG):** ejecuta únicamente APKs firmadas y verificadas. No compila ni ejecuta código generado por el modelo.
2. **Staging desechable:** entorno temporal sin credenciales de producción, sin acceso a RED LINE, sin llaves de firma y sin permisos de administración del teléfono. Aquí se generan y prueban parches.
3. **Verificador externo:** CI ejecuta pruebas, análisis estático, comprobaciones de dependencias y escaneo de secretos. Rechaza fallos y cambios a rutas protegidas.
4. **Aprobación y firma:** un operador independiente revisa el diff y autoriza el build. La llave de firma nunca está disponible para ULTRÓN ni para el entorno generador.
5. **Actualización:** el dispositivo acepta solo artefactos firmados por la llave fijada, valida versión/hash y conserva rollback.

## Rutas protegidas

- RED LINE, PIN y verificación de PIN.
- Política de acciones y allowlist.
- Credenciales/tokens, endpoint de revocación y claves de firma.
- Verificación de firmas, actualización/rollback y permisos Android.

Un cambio que toque cualquiera de estas rutas se rechaza automáticamente y requiere revisión de seguridad independiente. El modelo no puede cambiar las reglas que evalúan sus propios cambios.

## Límites explícitos

La revocación de `DEVICE_TOKEN` y de secretos del Worker deshabilita llamadas cloud, pero no revierte cambios locales ya instalados ni deshabilita capacidades offline del sistema operativo. Por ello no sustituye el aislamiento, la firma ni el rollback. La app 0.9 conserva el laboratorio de observaciones/propuestas; el ejecutor remoto de parches, la compilación desechable y el verificador de firma aún requieren desplegarse como infraestructura CI separada.
