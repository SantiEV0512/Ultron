# ULTRÓN — arquitectura de voz

## Versión 0.8.0
Esta versión incorpora `UltronVoice`, un adaptador local de Android TextToSpeech. Usa español de México cuando el motor instalado lo soporta y cambia a español genérico si hace falta. El tono y la velocidad se ajustan ligeramente para una presentación más grave y pausada. El resultado depende de las voces instaladas en Android y NO equivale a una voz clonada.

El botón **Probar voz de ULTRÓN (local)** permite comprobar el respaldo sin API key ni Internet. Algunas instalaciones de Android 6 pueden requerir descargar una voz española desde los ajustes del motor TTS.

## Versión 0.9.0 — integración prevista
- Fish Audio `POST https://api.fish.audio/v1/tts` o WebSocket live para audio progresivo.
- Modelo gratuito indicado por Fish: `s2.1-pro-free`, sujeto a condiciones, límites y cambios del proveedor.
- `reference_id`/Voice ID se tratará como configuración, no como secreto. La API key sí es un secreto y no se debe subir al repositorio.
- Si la API falla, el teléfono recurrirá al motor Android TTS.
- El cerebro LLM debe producir texto en streaming; el cliente agrupará fragmentos breves y los enviará al motor de voz para reducir el tiempo hasta el primer audio.

## Voz de una persona real o personaje
Solo se integrará una voz clonada de una persona identificable si existe consentimiento previo verificable o autorización/licencia aplicable. Para una voz de catálogo, comprobaremos las condiciones del creador y del proveedor. Una voz que imita a un personaje ficticio puede tener restricciones de franquicia, especialmente fuera de pruebas personales.

## Límites de rendimiento
El objetivo de producto es empezar a reproducir voz en menos de 2 segundos cuando red, LLM y proveedor lo permitan. No es una garantía: depende de latencia, tamaño del primer fragmento, cobertura, carga del servicio y disponibilidad del motor local. Android 6 y el hardware del LG también deben probarse físicamente.
