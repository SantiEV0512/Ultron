# ULTRÓN 0.9.1 — configuración y puesta en marcha

Esta versión corrige validaciones del Worker, endurece el cliente HTTPS de Android, mejora la reproducción asíncrona de Fish Audio y añade pruebas automatizadas para los servicios cloud. Sigue siendo una versión candidata: necesita despliegue y prueba en el LG real.

## 1. Requisitos externos

- Cuenta de Cloudflare con Workers y D1.
- App de Meta con WhatsApp Business Platform, número habilitado y token con permisos de mensajería.
- Proyecto de Google Cloud con Gmail API y consentimiento OAuth del titular de la cuenta.
- Cuenta/clave de Fish Audio y autorización para usar la voz asociada al `reference_id`.
- Cuenta de Groq.
- Repositorio GitHub para compilar la APK con Actions.

Los servicios pueden tener límites, verificaciones o costes propios. No se incluyen claves ni cuentas dentro del ZIP.

## 2. Cloudflare Worker y D1

1. Crea una base D1 y sustituye `REPLACE_WITH_YOUR_D1_DATABASE_ID` en `cloudflare/wrangler.toml`.
2. Desde la carpeta `cloudflare/`, aplica `schema.sql` a la base nueva. Si vienes de 0.8.3, no vuelvas a crear las columnas `ack_at` y `ack_result`; comprueba que existan.
3. Configura dos tokens aleatorios distintos de al menos 32 caracteres: `DEVICE_TOKEN` y `ADMIN_TOKEN`.
4. Guarda secretos con `npx wrangler secret put NOMBRE`:

```text
DEVICE_TOKEN
ADMIN_TOKEN
GROQ_API_KEY
FISH_AUDIO_API_KEY
WHATSAPP_TOKEN
WHATSAPP_PHONE_NUMBER_ID
GOOGLE_CLIENT_ID
GOOGLE_CLIENT_SECRET
GOOGLE_REFRESH_TOKEN
```

5. En `wrangler.toml`, configura `ALLOWED_CONTACTS_JSON` con los destinatarios autorizados y `GMAIL_SENDER` con la cuenta Gmail autenticada. Mantén `WHATSAPP_API_VERSION = 'v27.0'`; revisa la versión antes de futuras actualizaciones.
6. Despliega con `npx wrangler deploy`.

No pegues claves en el código, en GitHub, en este chat ni en el APK. Si una clave ya se compartió, rótala.

## 3. Contactos permitidos

Ejemplo ilustrativo; sustituye todos los datos:

```json
[
  {"alias":"santi","phone":"5215512345678","email":"santi@example.com"},
  {"alias":"familia","phone":"5215587654321","email":"familia@example.com"}
]
```

El alias solo admite letras minúsculas, números, guion y guion bajo. Teléfonos en formato internacional, solo dígitos. Los correos deben ser válidos. No se aceptan alias duplicados. La lista del Worker y la lista local de ULTRÓN deben coincidir exactamente en alias, teléfono y correo.

## 4. WhatsApp Business

El envío usa WhatsApp Business Cloud API, no la app personal instalada en el LG. Debes configurar un número de WhatsApp Business, Phone Number ID y token de acceso válido. El contacto debe haber dado su consentimiento para recibir mensajes. Los mensajes de texto libres están sujetos a la ventana de atención de WhatsApp; fuera de ella Meta puede exigir una plantilla aprobada. Esta versión envía texto libre y no gestiona plantillas todavía. Si Meta rechaza el mensaje, ULTRÓN mostrará que no se confirmó el envío.

## 5. Gmail

Habilita Gmail API en Google Cloud y autoriza el alcance mínimo `https://www.googleapis.com/auth/gmail.send` con acceso offline. Guarda el refresh token y el client ID/secret en Cloudflare Secrets. `GMAIL_SENDER` debe ser la misma cuenta autenticada. Google puede exigir verificación o limitar aplicaciones OAuth en modo prueba.

## 6. Fish Audio y Groq

La clave Fish Audio y la clave Groq permanecen en Cloudflare Secrets. El modelo predeterminado de Groq es `openai/gpt-oss-120b`; se eligió porque Groq retiró `llama-3.3-70b-versatile` el 16 de agosto de 2026. El identificador de voz está en `FISH_AUDIO_REFERENCE_ID`; el audio se devuelve como MP3. Si Fish Audio no está disponible, ULTRÓN usa Android TextToSpeech como respaldo. La disponibilidad de la voz depende de los derechos y permisos del titular del modelo de voz.

## 7. App Android 6

1. En GitHub, sube el contenido de este proyecto a un repositorio.
2. Ejecuta **Actions → Build Dawncore AI Phone APK → Run workflow**. La acción ejecuta pruebas del Worker y después compila el APK debug.
3. Descarga el artefacto `Dawncore-AI-Phone-v0.9.1-debug-apk`.
4. Instala la APK en el LG Android 6. Configura la URL HTTPS del Worker y `DEVICE_TOKEN` desde **Administración remota**.
5. Añade localmente los mismos contactos autorizados del Worker.
6. Configura RED LINE y prueba primero con cuentas y números de prueba propios.

No se requiere permiso SMS y la app no implementa SMS.

## 8. Seguridad y límites

- La lista local y la lista del servidor se comprueban antes del envío; el servidor vuelve a validar alias y destino exactos.
- El LLM solo interpreta órdenes; no puede agregar contactos ni saltarse RED LINE.
- El cliente rechaza URL no HTTPS y no sigue redirecciones que podrían exponer el token.
- Los mensajes y correos se envían tras una orden explícita del usuario. No hay envíos espontáneos ni campañas automáticas.
- RED LINE bloquea acciones dentro de ULTRÓN, no todo Android. Sin Device Owner no hay bloqueo total del teléfono.
- La evolución de código continúa aislada: ULTRÓN puede proponer cambios, pero no alterar sus políticas, llaves de firma o RED LINE ni publicar por sí solo en producción.
- El puente remoto reintenta entregar órdenes no confirmadas tras una concesión temporal; el polling sigue siendo manual y no garantiza recepción si el teléfono está offline o no abre la app.

## 9. Pruebas ejecutadas y pendientes

Ejecuta localmente:

```bash
cd cloudflare
npm test
node --check src/index.js
```

La CI hace estas comprobaciones y compila el APK. Antes de considerar 0.9.1 lista para uso real, todavía hay que instalarla y probarla en el LG Android 6, configurar las cuentas reales y verificar un envío de prueba con consentimiento. El entorno de creación del ZIP no tiene Android SDK/Gradle/ADB; por tanto no se afirma que el APK ya haya sido compilado ni probado en el dispositivo.
