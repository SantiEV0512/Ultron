# Security Core

- El LLM es entrada no confiable: solo devuelve `action`, `alias`, `message`, `subject`, `body`.
- La aplicación nunca toma un número o correo del texto generado por el LLM.
- El alias debe existir en la lista blanca local.
- Cada acción externa requiere confirmación visible.
- La API key se cifra con AES/GCM y Android Keystore.
- La captura de notificaciones queda local y solo conserva la última notificación compatible.
- No guardar contraseñas de WhatsApp o correo.

Una app común no puede imponer por sí sola una lista blanca global sobre el marcador y otras aplicaciones. Para restringir el dispositivo completo se necesita Device Owner/Lock Task y aprovisionamiento dedicado, lo cual se evaluará después de verificar el firmware.
