# RED LINE 0.8.1 — Security Core

## Purpose and security boundary
RED LINE is an independent local policy gate for Dawncore AI Phone. ULTRÓN/the LLM cannot read the PIN, hash, salt, lock state or change the policy. All supported external actions are checked again immediately before dispatch.

## Included in 0.8.1
- Mandatory local administrator PIN setup before any phone action can be executed.
- PIN length 6–8 digits; rejects all-identical digits and simple ascending/descending sequences.
- Random 128-bit salt and PBKDF2-HMAC-SHA1 (60,000 iterations) hash; PIN is never stored in plaintext.
- Constant-time hash comparison.
- Progressive retry delay after four failed attempts, capped at five minutes. There is no permanent lockout, to avoid accidental owner denial of service.
- Authenticated local PIN change.
- Manual RED LINE activation.
- Automatic activation when the LLM/parser proposes a recipient outside the explicit allowlist (only after PIN setup).
- Final action gate: no action while locked, before PIN setup, for unknown actions, or with missing destination/content.
- Persistent app-level lock state and local PIN recovery screen.
- Bounded diagnostic audit log (last 100 events) for PIN, lock and action-gate events.
- App relaunch/resume checks the persistent lock flag.

## Not included / cannot honestly be promised
- This does **not** lock Android globally, disable Home/Settings, prevent uninstall, or survive clearing app data/factory reset.
- This does not yet have a remote administration backend or web unlock. No cloud command is accepted in this version.
- It is not an anti-theft service and does not use or need the IMEI.
- The local audit log is diagnostic, not tamper-proof forensic evidence.
- It cannot stop the device owner from force-stopping/uninstalling the app or using Android recovery.

## Remote administration roadmap
A future remote unlock must use a separately authenticated backend, TLS, short-lived signed commands, replay protection (unique command IDs and expiry), revocation, and a key not accessible to the LLM. No API secret or PIN belongs in Git. A remote unlock must never be accepted from an unsigned notification or arbitrary URL.

## Device-owner / kiosk mode
A stronger device-wide kiosk mode requires deliberate Android Device Owner provisioning and may require factory reset. It must be opt-in, documented, tested on this exact LG model, and include an owner-controlled recovery path. Do not silently enable it.

## Recovery
Keep the administrator PIN in a password manager or another secure place. If it is lost while the app is locked, this version has no remote recovery. Clearing app data may remove the lock but also destroys app configuration and is not a secure recovery method.
