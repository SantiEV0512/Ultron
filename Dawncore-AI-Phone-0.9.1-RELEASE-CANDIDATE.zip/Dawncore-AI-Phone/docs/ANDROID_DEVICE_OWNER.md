# Bloqueo administrado en Android 6 (API 23)

Una Activity de pantalla completa NO puede impedir que el usuario salga a Inicio, abra Ajustes, desinstale la app o reinicie el teléfono. Para una política de dispositivo se necesita `DevicePolicyManager` y una app Device Owner aprovisionada.

## Requisitos y advertencias
- Device Owner normalmente se configura durante el aprovisionamiento inicial, antes de añadir cuentas, y requiere que el dispositivo esté recién restablecido de fábrica.
- El método de desarrollo habitual usa ADB desde un ordenador con USB debugging: `adb shell dpm set-device-owner com.dawncore.aiphone/.DawncoreDeviceAdminReceiver` (el receiver y el manifiesto deben implementarse y probarse antes; este comando es orientativo, no ejecutar aún).
- No hay garantía de que pueda completarse únicamente desde el LG. Un segundo teléfono Android con USB-OTG y una herramienta ADB puede servir en algunos escenarios, pero no es un método garantizado ni sustituye las pruebas.
- El restablecimiento borra los datos del LG. Hacer copia de seguridad y obtener autorización del propietario antes de proceder.
- La app debe implementar un `DeviceAdminReceiver`, declarar `BIND_DEVICE_ADMIN`, solicitar aprovisionamiento y verificar `isDeviceOwnerApp()` antes de activar políticas.

## Qué permite estudiar
Con Device Owner, Android ofrece políticas como `lockNow()`, `setLockTaskPackages()` y `setLockTaskFeatures()` (verificar disponibilidad exacta por API). El modo Lock Task/kiosk puede limitar navegación fuera de la app cuando está correctamente aprovisionado.

## Límites que no se deben prometer
- No es un antirrobo invulnerable: recuperación, reinicio, recovery, bootloader, firmware, fallos del sistema y restablecimiento físico dependen del modelo y de sus protecciones.
- No usar accesibilidad como mecanismo de bloqueo. No ocultar controles de recuperación al propietario.
- No activar bloqueo total hasta tener PIN local probado, restauración de fábrica documentada, y un método de salida de emergencia administrado por el propietario.
- El bloqueo remoto necesita que el teléfono esté encendido, conectado y que el agente de administración esté ejecutándose.
