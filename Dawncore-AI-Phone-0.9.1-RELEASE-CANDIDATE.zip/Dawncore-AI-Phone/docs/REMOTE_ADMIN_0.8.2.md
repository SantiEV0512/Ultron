# RED LINE Remote Administration — 0.8.2

## Included in this package
- Cloudflare Worker REST backend (`cloudflare/src/index.js`).
- D1 schema for short-lived, one-use LOCK/UNLOCK commands.
- Minimal responsive admin web app (`admin-web/index.html`).
- No credentials or tokens are embedded in source.

## Important integration status
This is the backend and dashboard scaffold, **not an end-to-end remote lock release**. The Android app in this archive has not yet been wired to poll `/device/command`, authenticate with a per-device secret stored using Android Keystore, and apply the received command. Do not treat a dashboard message saying “accepted” as proof the LG is locked. The dashboard currently reports backend command state only.

## Deploy backend
1. Create a Cloudflare account and a D1 database named `dawncore-redline`.
2. Apply `schema.sql` to that D1 database.
3. Replace `database_id` in `wrangler.toml` with the database ID.
4. Set secrets with Wrangler: `wrangler secret put ADMIN_TOKEN` and `wrangler secret put DEVICE_TOKEN`. Use two independent random values of at least 32 bytes. Never commit them.
5. Deploy with `wrangler deploy`.
6. Set the Worker URL in `admin-web/index.html` by replacing `https://REPLACE_WITH_WORKER_DOMAIN`.
7. Host `admin-web` as a static site over HTTPS. Restrict access; do not publish it as an indexed public page.

## API
- `GET /health` — public health check.
- `POST /admin/command` — `Authorization: Bearer ADMIN_TOKEN`; JSON `{ "deviceId":"ultron-lg-k240h", "action":"LOCK|UNLOCK", "reason":"..." }`.
- `GET /admin/status?deviceId=...` — admin token required.
- `GET /device/command?deviceId=...` — device token required; consumes one pending command. Commands expire after five minutes.

## Before production
- Replace the shared prototype device token with unique per-device credentials and a pairing/revocation flow.
- Add rate limiting, audit retention policy, CSRF/origin controls for dashboard deployment, account MFA, alerting, and key rotation.
- Device must poll over HTTPS, verify response schema, persist command ID to prevent replay, apply command locally, and acknowledge result. Never let an LLM parse or authorize these commands.
- UNLOCK must require both authenticated remote administrator authorization and local policy checks; preserve a separately configured owner recovery route.
- A network command is best-effort: a powered-off/offline phone cannot receive it.

## Privacy
Do not collect or transmit IMEI. Use a random app-generated device identifier. Do not send contacts, message content, API keys, or notification contents to this backend.
