# Pruebas antes de uso real
1. Instalar en dispositivo de prueba.
2. Añadir solo un contacto propio.
3. Probar alias inexistente: debe bloquearse.
4. Probar llamada y denegar permiso: no debe llamar.
5. Probar llamada al propio número.
6. Preparar WhatsApp al propio número; revisar destinatario y mensaje antes de tocar Enviar.
7. Preparar correo propio; revisar antes de Enviar.
8. Probar LLM con orden inocua y alias inventado: debe bloquearse.
9. Desactivar Internet: el parser local debe seguir funcionando.
10. Activar acceso a notificaciones y comprobar solo vista previa.
11. Reiniciar y comprobar persistencia.
12. No usar esta versión para comunicaciones desatendidas ni llamadas de emergencia.


## 0.8.3 remote bridge and Evolution Lab
10. Configure a test Worker URL and token; verify non-HTTPS URLs are rejected.
11. Verify the app generates a random installation ID and does not use IMEI.
12. Queue LOCK in the admin panel, tap Comprobar órdenes remotas, and verify the app enters RED LINE.
13. Queue UNLOCK; verify it does not unlock automatically and still requires the local PIN.
14. Verify admin status reports command acknowledgement.
15. Disable network and poll; verify an error is shown and no remote success is claimed.
16. Add an observation and proposal in Evolution Lab; close/reopen and verify persistence.
17. Verify Evolution Lab cannot modify PIN, allowlist, RED LINE, app files or execute generated code.
18. Retest all existing call/WhatsApp/email allowlist and confirmation cases.
