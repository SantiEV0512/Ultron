# RED LINE Remote Administration — 0.8.3

## Setup
1. Deploy the Cloudflare Worker and D1 database.
2. Set Worker secrets `ADMIN_TOKEN` and `DEVICE_TOKEN` independently, each at least 32 random characters. Never commit them.
3. Set the Worker variable `ADMIN_WEB_ORIGIN` to the exact HTTPS origin hosting `admin-web` (for example, your Cloudflare Pages origin, without a path). The Worker rejects browser preflight requests from other origins.
4. Host the admin web app over HTTPS and restrict access. The dashboard uses `ADMIN_TOKEN`; the LG app uses `DEVICE_TOKEN`.
5. In ULTRÓN, choose **Configurar administración remota** and enter the Worker HTTPS base URL plus DEVICE_TOKEN. The token is encrypted at rest using Android Keystore AES-GCM.
6. Copy the random installation ID displayed by the app into the admin dashboard. The dashboard no longer has a fabricated default ID.
7. Queue LOCK/UNLOCK in the dashboard. On the phone, tap **Comprobar órdenes remotas**.

## API
- `GET /health` — public health.
- `POST /admin/command` — ADMIN_TOKEN; JSON `{deviceId, action:"LOCK"|"UNLOCK", reason}`.
- `GET /device/command?deviceId=...` — DEVICE_TOKEN; returns one pending, unexpired command.
- `POST /device/ack` — DEVICE_TOKEN; JSON `{deviceId, commandId, result}`.
- `GET /admin/status?deviceId=...` — ADMIN_TOKEN; returns latest command and acknowledgement state.

Commands expire after five minutes. In 0.9.1, delivery is leased for 30 seconds and an unacknowledged command can be delivered again after the lease expires. Polling is still manual.

## Behavior
- LOCK activates the local app-level RED LINE lock.
- UNLOCK is recorded as a request only. The phone still requires the local PIN.
- Remote control cannot work if the phone is offline, powered off, force-stopped, or has not polled.

## Existing D1 migration
For a new DB, apply `cloudflare/schema.sql`. For an existing 0.8.2 DB, run:
```sql
ALTER TABLE commands ADD COLUMN ack_at INTEGER;
ALTER TABLE commands ADD COLUMN ack_result TEXT;
```

## Remaining security work
The backend currently uses a shared DEVICE_TOKEN. Production requires device enrollment, per-device secrets, revocation/rotation, command replay protection, rate limiting, admin MFA and an audited recovery path. The app uses HTTPS and Keystore encryption but these do not remove the shared-token limitation. Do not transmit IMEI, contacts, message contents, notification contents, LLM keys, or PIN data.
