# ULTRÓN 0.9 — configuración de servicios

## Qué hace esta versión

- Envía mensajes de texto por WhatsApp Business Cloud API y correos mediante Gmail API desde el Worker; no abre borradores.
- Solo permite alias y direcciones/teléfonos que coincidan exactamente con `ALLOWED_CONTACTS_JSON` en el servidor y con la lista local del teléfono.
- Interpreta órdenes con Groq a través del Worker. La clave Groq no se introduce en el APK.
- Genera voz con Fish Audio a través del Worker. La voz de respaldo local Android permanece disponible.
- No incorpora SMS.
- Los envíos de WhatsApp/Gmail se ejecutan tras una orden explícita del usuario; no se envían mensajes espontáneos ni se permite que el modelo elija un destinatario no autorizado.

## 1. Publicar el Worker

Desde `cloudflare/`, configura el binding D1 existente y ejecuta las migraciones del esquema. Después define secretos (no los escribas en `wrangler.toml`, GitHub ni el APK):

```bash
npx wrangler secret put DEVICE_TOKEN
npx wrangler secret put ADMIN_TOKEN
npx wrangler secret put GROQ_API_KEY
npx wrangler secret put FISH_AUDIO_API_KEY
npx wrangler secret put WHATSAPP_TOKEN
npx wrangler secret put WHATSAPP_PHONE_NUMBER_ID
npx wrangler secret put GOOGLE_CLIENT_ID
npx wrangler secret put GOOGLE_CLIENT_SECRET
npx wrangler secret put GOOGLE_REFRESH_TOKEN
```

`DEVICE_TOKEN` y `ADMIN_TOKEN` deben ser cadenas aleatorias distintas, largas y únicas. Si alguna clave fue pegada en una conversación o repositorio, rótala antes de producción.

Configura también `GMAIL_SENDER` como variable del Worker con la dirección remitente autorizada. `FISH_AUDIO_REFERENCE_ID` está en `wrangler.toml` como identificador público de voz, no como clave. La versión de Meta Graph API debe verificarse con la documentación vigente antes de desplegar; actualiza `WHATSAPP_API_VERSION` si Meta ya retiró la versión indicada.

## 2. Lista de destinatarios autorizados

Edita `ALLOWED_CONTACTS_JSON` en variables del Worker. Ejemplo ilustrativo, reemplaza los datos por los de tus contactos autorizados:

```json
[
  {"alias":"santi","phone":"5215512345678","email":"santi@example.com"},
  {"alias":"familia","phone":"5215587654321","email":"familia@example.com"}
]
```

Los teléfonos deben estar en formato internacional, solo dígitos. La dirección de correo y el teléfono deben coincidir exactamente con los del registro local. No agregues contactos sin su autorización.

## 3. WhatsApp Business

Crea/configura una app de Meta con WhatsApp Business Platform, un número habilitado y un token de acceso apropiado. Registra el Phone Number ID en el secreto/variable `WHATSAPP_PHONE_NUMBER_ID` (variable de Worker). Los destinatarios deben haber dado su consentimiento y se aplican las reglas de ventana de atención y plantillas de WhatsApp. La API no envía desde la cuenta personal de WhatsApp instalada en el LG.

## 4. Gmail

Configura un proyecto de Google Cloud, habilita Gmail API y crea credenciales OAuth de tipo aplicación web/cliente apropiado. Obtén un refresh token con el alcance mínimo `https://www.googleapis.com/auth/gmail.send`, acceso offline y consentimiento del titular de la cuenta. Guarda el refresh token y los datos de cliente como secretos del Worker. `GMAIL_SENDER` debe corresponder a la cuenta autenticada. Google puede exigir verificación o limitar aplicaciones OAuth en modo prueba.

## 5. App Android 6

Instala la APK generada por GitHub Actions y, dentro de ULTRÓN, configura la URL HTTPS del Worker y el `DEVICE_TOKEN`. Añade localmente los mismos alias, teléfonos y correos que aparecen en la lista del servidor. La app no necesita permisos SMS. Las llamadas siguen pidiendo permiso del sistema.

## 6. RED LINE y límites

RED LINE bloquea las acciones dentro de ULTRÓN. No puede bloquear todo Android ni garantizar control total del teléfono sin aprovisionamiento Device Owner. La revocación de claves deshabilita los servicios cloud, pero no revierte código local alterado. Por eso las actualizaciones deben seguir aisladas, verificadas y firmadas fuera del agente; ULTRÓN no puede modificar sus políticas, claves de firma ni RED LINE.

## 7. Pruebas antes de producción

1. `/health` devuelve estado online.
2. Token de dispositivo incorrecto recibe HTTP 401.
3. Alias no registrado recibe HTTP 403.
4. Alias registrado con teléfono/correo distinto recibe HTTP 400.
5. Mensaje WhatsApp de prueba solo a un número de prueba con opt-in.
6. Correo de prueba solo a una cuenta controlada.
7. Fish Audio reproduce el audio generado y la app vuelve al motor local si falla.
8. RED LINE activado impide todas las acciones; el desbloqueo sigue requiriendo PIN local.
9. Revocar `DEVICE_TOKEN` impide todas las llamadas al Worker desde el teléfono.

El diseño de evolución aislada está descrito en `EVOLUTION_PIPELINE_0.9.md`; el ejecutor de parches y la infraestructura CI separada todavía no están implementados.

Esta versión no debe considerarse lista para producción hasta completar los pasos de configuración y pruebas en un LG real con Android 6.
