# RED LINE 0.8.1 — Manual test plan

Run on the target LG X Max (Android 6 / API 23) before treating this release as production-ready.

1. Fresh install: verify no phone action runs before RED LINE PIN setup.
2. Configure a valid 6–8 digit PIN; verify repeated digits and simple sequences are rejected.
3. Close/reopen app; verify PIN configuration remains.
4. Change PIN using old PIN; verify old PIN fails and new PIN succeeds.
5. Enter four incorrect PINs; verify a delay appears after the threshold and is not permanent.
6. Activate RED LINE manually; verify the lock screen displays reason/time and survives app relaunch.
7. Unlock with correct PIN; verify app returns and lock state clears.
8. Ask ULTRÓN to contact an alias not on the allowlist; verify RED LINE activates.
9. Try an allowed contact with missing phone/email/message; verify no external app opens.
10. While locked, return to the app; verify lock screen is presented again.
11. Inspect audit log; verify events are bounded and do not contain PIN, API key, message body, phone number or email address.
12. Test Home, Recents, Settings, force-stop, uninstall and clear-data behavior. Confirm these remain Android-level escape/recovery paths; do not represent this build as a system lock.
13. Test on slow device and check PIN verification latency; if unacceptable, benchmark before changing KDF parameters.

A passing static ZIP/XML check is not a substitute for these device tests or a successful cloud APK build.
