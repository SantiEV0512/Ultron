package com.dawncore.aiphone;

import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** HTTPS-only gateway. Provider credentials never enter the APK. */
public final class CloudAssistantClient {
    public interface Callback { void done(boolean ok, String message); }
    private CloudAssistantClient() {}

    private static String baseUrl(Context context) {
        String value = context.getSharedPreferences("dawncore", Context.MODE_PRIVATE)
                .getString("remote_url", "");
        if (value == null) return "";
        value = value.trim();
        while (value.endsWith("/")) value = value.substring(0, value.length() - 1);
        Uri uri = Uri.parse(value);
        if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null ||
                uri.getUserInfo() != null || uri.getQuery() != null || uri.getFragment() != null) return "";
        return value;
    }

    private static String deviceToken(Context context) {
        String token = RemoteCredentials.readToken(context);
        return token == null ? "" : token;
    }

    public static void send(Context context, String route, JSONObject payload, Callback callback) {
        final Context app = context.getApplicationContext();
        final String base = baseUrl(app);
        final String token = deviceToken(app);
        if (!"/assistant/whatsapp".equals(route) && !"/assistant/gmail".equals(route) && !"/assistant/llm".equals(route)) {
            if (callback != null) callback.done(false, "Ruta de servicio no permitida.");
            return;
        }
        if (base.isEmpty() || token.length() < 32) {
            if (callback != null) callback.done(false, "Configura primero el Worker HTTPS y su token de dispositivo.");
            return;
        }
        new AsyncTask<Void, Void, String>() {
            int code = 0;
            protected String doInBackground(Void... ignored) {
                HttpURLConnection connection = null;
                try {
                    connection = (HttpURLConnection) new URL(base + route).openConnection();
                    connection.setInstanceFollowRedirects(false);
                    connection.setRequestMethod("POST");
                    connection.setConnectTimeout(12000);
                    connection.setReadTimeout(25000);
                    connection.setUseCaches(false);
                    connection.setDoOutput(true);
                    connection.setRequestProperty("Authorization", "Bearer " + token);
                    connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                    byte[] bytes = payload.toString().getBytes(StandardCharsets.UTF_8);
                    connection.setFixedLengthStreamingMode(bytes.length);
                    try (OutputStream out = connection.getOutputStream()) { out.write(bytes); }
                    code = connection.getResponseCode();
                    InputStream in = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
                    if (in == null) return "El servidor respondió HTTP " + code + ".";
                    ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                    byte[] chunk = new byte[2048];
                    int count;
                    while ((count = in.read(chunk)) != -1) buffer.write(chunk, 0, count);
                    in.close();
                    JSONObject result = new JSONObject(new String(buffer.toByteArray(), StandardCharsets.UTF_8));
                    return result.optString("message", result.optString("content",
                            result.optString("error", code >= 200 && code < 300 ? "Operación completada." : "Error del servidor.")));
                } catch (Exception e) {
                    return "No se pudo contactar el servicio seguro (" + e.getClass().getSimpleName() + ").";
                } finally { if (connection != null) connection.disconnect(); }
            }
            protected void onPostExecute(String result) {
                if (callback != null) callback.done(code >= 200 && code < 300, result);
            }
        }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
    }

    public static void speakFish(Context context, String text, Callback callback) {
        final Context app = context.getApplicationContext();
        final String base = baseUrl(app);
        final String token = deviceToken(app);
        if (base.isEmpty() || token.length() < 32) {
            if (callback != null) callback.done(false, "Configura el Worker HTTPS.");
            return;
        }
        new AsyncTask<Void, Void, File>() {
            String error = "No se pudo generar audio.";
            protected File doInBackground(Void... ignored) {
                HttpURLConnection connection = null;
                File file = null;
                try {
                    connection = (HttpURLConnection) new URL(base + "/assistant/voice").openConnection();
                    connection.setInstanceFollowRedirects(false);
                    connection.setRequestMethod("POST");
                    connection.setConnectTimeout(12000);
                    connection.setReadTimeout(45000);
                    connection.setUseCaches(false);
                    connection.setDoOutput(true);
                    connection.setRequestProperty("Authorization", "Bearer " + token);
                    connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                    byte[] bytes = new JSONObject().put("text", text).toString().getBytes(StandardCharsets.UTF_8);
                    connection.setFixedLengthStreamingMode(bytes.length);
                    try (OutputStream out = connection.getOutputStream()) { out.write(bytes); }
                    int status = connection.getResponseCode();
                    if (status < 200 || status >= 300) { error = "Fish Audio/Worker respondió HTTP " + status + "."; return null; }
                    String contentType = connection.getContentType();
                    if (contentType == null || !contentType.toLowerCase(java.util.Locale.ROOT).contains("audio/")) {
                        error = "El servicio no devolvió un archivo de audio válido.";
                        return null;
                    }
                    file = File.createTempFile("ultron-voice-", ".mp3", app.getCacheDir());
                    try (InputStream in = connection.getInputStream(); FileOutputStream out = new FileOutputStream(file)) {
                        byte[] chunk = new byte[4096];
                        int count;
                        while ((count = in.read(chunk)) != -1) out.write(chunk, 0, count);
                    }
                    if (file.length() < 128) { file.delete(); error = "Audio vacío o inválido."; return null; }
                    return file;
                } catch (Exception e) {
                    if (file != null) file.delete();
                    error = "No se pudo generar audio (" + e.getClass().getSimpleName() + ").";
                    return null;
                } finally { if (connection != null) connection.disconnect(); }
            }
            protected void onPostExecute(File file) {
                if (file == null) { if (callback != null) callback.done(false, error); return; }
                final MediaPlayer player = new MediaPlayer();
                try {
                    player.setAudioStreamType(AudioManager.STREAM_MUSIC);
                    player.setDataSource(file.getAbsolutePath());
                    player.setOnCompletionListener(mp -> { mp.release(); file.delete(); });
                    player.setOnErrorListener((mp, what, extra) -> {
                        mp.release(); file.delete();
                        if (callback != null) callback.done(false, "No se pudo reproducir el audio.");
                        return true;
                    });
                    player.setOnPreparedListener(mp -> {
                        mp.start();
                        if (callback != null) callback.done(true, "Voz Fish Audio reproduciéndose.");
                    });
                    player.prepareAsync();
                } catch (Exception e) {
                    player.release(); file.delete();
                    if (callback != null) callback.done(false, "Error de reproducción: " + e.getClass().getSimpleName());
                }
            }
        }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
    }
}
