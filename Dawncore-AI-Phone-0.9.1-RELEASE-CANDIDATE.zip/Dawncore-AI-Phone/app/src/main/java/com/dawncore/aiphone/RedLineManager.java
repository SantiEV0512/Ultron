package com.dawncore.aiphone;

import android.content.Context;
import android.content.SharedPreferences;
import java.security.MessageDigest;
import java.security.SecureRandom;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** Local policy gate. The LLM cannot read or change its PIN, lock state or policy. */
public final class RedLineManager {
    private static final String PREFS = "dawncore_redline";
    private static final int ITERATIONS = 60000; // benchmark on the target MT6735 before increasing
    private static final int MIN_PIN = 6, MAX_PIN = 8;
    private RedLineManager() {}

    private static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }
    public static boolean isConfigured(Context c) { return !prefs(c).getString("pin_hash", "").isEmpty(); }
    public static boolean isLocked(Context c) { return prefs(c).getBoolean("locked", false); }
    public static String reason(Context c) { return prefs(c).getString("reason", "Protocolo RED LINE activado."); }
    public static long lockedAt(Context c) { return prefs(c).getLong("locked_at", 0L); }
    public static long pinBlockedUntil(Context c) { return prefs(c).getLong("pin_blocked_until", 0L); }
    public static int pinFailures(Context c) { return prefs(c).getInt("pin_failures", 0); }

    public static void setPin(Context c, String pin) throws Exception {
        validatePin(pin);
        byte[] salt = new byte[16]; new SecureRandom().nextBytes(salt);
        byte[] hash = derive(pin.toCharArray(), salt);
        boolean ok = prefs(c).edit().putString("pin_salt", hex(salt)).putString("pin_hash", hex(hash))
                .putInt("pin_failures", 0).putLong("pin_blocked_until", 0L).commit();
        if (!ok) throw new IllegalStateException("No se pudo guardar la configuración de seguridad.");
        RedLineAudit.record(c, "PIN_CONFIGURED", "PIN de administrador configurado");
    }

    public static void changePin(Context c, String oldPin, String newPin) throws Exception {
        if (!verifyPin(c, oldPin)) throw new SecurityException("PIN actual incorrecto o temporalmente bloqueado.");
        setPin(c, newPin);
        RedLineAudit.record(c, "PIN_CHANGED", "PIN de administrador actualizado");
    }

    public static boolean verifyPin(Context c, String pin) {
        try {
            if (pin == null || System.currentTimeMillis() < pinBlockedUntil(c)) return false;
            String saltText = prefs(c).getString("pin_salt", "");
            String hashText = prefs(c).getString("pin_hash", "");
            if (saltText.isEmpty() || hashText.isEmpty()) return false;
            byte[] expected = unhex(hashText);
            byte[] actual = derive(pin.toCharArray(), unhex(saltText));
            boolean ok = MessageDigest.isEqual(expected, actual);
            if (ok) {
                prefs(c).edit().putInt("pin_failures", 0).putLong("pin_blocked_until", 0L).commit();
                RedLineAudit.record(c, "PIN_ACCEPTED", "PIN local verificado");
            } else {
                int failures = pinFailures(c) + 1;
                long delay = failures < 5 ? 0L : Math.min(300000L, 30000L * (long)(failures - 4));
                prefs(c).edit().putInt("pin_failures", failures)
                        .putLong("pin_blocked_until", System.currentTimeMillis() + delay).commit();
                RedLineAudit.record(c, "PIN_REJECTED", "Intento de PIN incorrecto; intentos=" + failures);
            }
            return ok;
        } catch (Exception e) { return false; }
    }

    public static void activate(Context c, String why) {
        String safe = why == null ? "Incumplimiento de política." : why.trim();
        if (safe.length() > 180) safe = safe.substring(0, 180);
        boolean wasLocked = isLocked(c);
        boolean ok = prefs(c).edit().putBoolean("locked", true).putString("reason", safe)
                .putLong("locked_at", System.currentTimeMillis()).commit();
        if (ok && !wasLocked) RedLineAudit.record(c, "LOCK_ACTIVATED", safe);
    }

    public static boolean unlock(Context c, String pin) {
        if (!isLocked(c) || !verifyPin(c, pin)) return false;
        boolean ok = prefs(c).edit().putBoolean("locked", false).putString("reason", "")
                .putInt("pin_failures", 0).putLong("pin_blocked_until", 0L).commit();
        if (ok) RedLineAudit.record(c, "LOCK_RELEASED", "Bloqueo liberado mediante PIN local");
        return ok;
    }

    /** All external actions must pass this gate immediately before execution. */
    public static boolean canExecute(Context c, ActionPlan plan, ContactEntry contact) {
        if (isLocked(c) || !isConfigured(c) || plan == null || contact == null) return false;
        if (plan.type == ActionPlan.Type.UNKNOWN) return false;
        if (plan.type == ActionPlan.Type.CALL) return !contact.phone.isEmpty();
        if (plan.type == ActionPlan.Type.WHATSAPP) return !contact.phone.isEmpty() && plan.message != null && !plan.message.trim().isEmpty();
        if (plan.type == ActionPlan.Type.EMAIL) return !contact.email.isEmpty() && plan.subject != null && !plan.subject.trim().isEmpty() && plan.body != null && !plan.body.trim().isEmpty();
        return false;
    }

    public static void validatePin(String pin) {
        if (pin == null || !pin.matches("[0-9]{6,8}")) throw new IllegalArgumentException("El PIN debe tener entre 6 y 8 dígitos.");
        boolean same = true; for (int i = 1; i < pin.length(); i++) if (pin.charAt(i) != pin.charAt(0)) { same = false; break; }
        if (same || "0123456789".contains(pin) || "9876543210".contains(pin))
            throw new IllegalArgumentException("Elige un PIN menos predecible; evita dígitos repetidos o secuencias.");
    }

    private static byte[] derive(char[] pin, byte[] salt) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(pin, salt, ITERATIONS, 256);
        try { return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).getEncoded(); }
        finally { spec.clearPassword(); }
    }
    private static String hex(byte[] data) { StringBuilder b = new StringBuilder(); for (byte v : data) b.append(String.format(java.util.Locale.US, "%02x", v & 255)); return b.toString(); }
    private static byte[] unhex(String s) { if (s.length() % 2 != 0) throw new IllegalArgumentException("hex"); byte[] out = new byte[s.length()/2]; for (int i=0;i<out.length;i++) out[i]=(byte)Integer.parseInt(s.substring(i*2,i*2+2),16); return out; }
}
