package com.dawncore.aiphone;
import java.util.Locale;
public final class CommandParser {
 private CommandParser(){}
 public static ActionPlan parse(String raw){if(raw==null)return null;String s=raw.trim(),l=s.toLowerCase(Locale.ROOT);
  if(l.startsWith("llamar a "))return new ActionPlan(ActionPlan.Type.CALL,s.substring(9).trim(),"","","");
  if(l.startsWith("whatsapp a ")){String r=s.substring(11);int c=r.indexOf(':');if(c<1||c==r.length()-1)return null;return new ActionPlan(ActionPlan.Type.WHATSAPP,r.substring(0,c),r.substring(c+1).trim(),"","");}
  int start=l.startsWith("correo a ")?9:l.startsWith("email a ")?8:-1;if(start>=0){String r=s.substring(start);int c=r.indexOf(':');if(c<1)return null;String payload=r.substring(c+1).trim();int p=payload.indexOf('|');if(p<0)return null;return new ActionPlan(ActionPlan.Type.EMAIL,r.substring(0,c),"",payload.substring(0,p).trim(),payload.substring(p+1).trim());}
  return null;
 }
}
