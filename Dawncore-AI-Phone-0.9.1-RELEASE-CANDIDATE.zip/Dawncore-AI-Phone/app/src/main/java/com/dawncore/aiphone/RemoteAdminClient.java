package com.dawncore.aiphone;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;

/** HTTPS-only command bridge. LLM output cannot authorize or create remote commands. */
public final class RemoteAdminClient {
    public interface Callback { void done(String message, boolean success); }
    private RemoteAdminClient() {}

    public static String deviceId(Context c) {
        SharedPreferences p = c.getSharedPreferences("dawncore_remote", Context.MODE_PRIVATE);
        String value = p.getString("device_id", "");
        if (value.isEmpty()) {
            value = java.util.UUID.randomUUID().toString().replace("-", "");
            p.edit().putString("device_id", value).commit();
        }
        return value;
    }

    public static void poll(Context context, String baseUrl, Callback callback) {
        final Context app = context.getApplicationContext();
        final String base = trim(baseUrl);
        final String token = RemoteCredentials.readToken(app);
        final String device = deviceId(app);
        new AsyncTask<Void, Void, String>() {
            protected String doInBackground(Void... ignored) {
                Uri baseUri = Uri.parse(base);
                if (!"https".equalsIgnoreCase(baseUri.getScheme()) || baseUri.getHost() == null ||
                        baseUri.getUserInfo() != null || baseUri.getQuery() != null || baseUri.getFragment() != null || token.length() < 32)
                    return "Configura una URL HTTPS válida y un token remoto de al menos 32 caracteres.";
                if (!RedLineManager.isConfigured(app))
                    return "Configura primero el PIN local de RED LINE antes de habilitar órdenes remotas.";
                HttpURLConnection connection = null;
                try {
                    URL endpoint = new URL(base + "/device/command?deviceId=" + device);
                    connection = (HttpURLConnection) endpoint.openConnection();
                    connection.setInstanceFollowRedirects(false);
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(10000);
                    connection.setReadTimeout(10000);
                    connection.setRequestProperty("Authorization", "Bearer " + token);
                    connection.setRequestProperty("Accept", "application/json");
                    int code = connection.getResponseCode();
                    String body = readBody(code >= 400 ? connection.getErrorStream() : connection.getInputStream());
                    if (code != 200) return "Servidor remoto respondió HTTP " + code + ".";
                    JSONObject root = new JSONObject(body);
                    if (root.isNull("command")) return "Sin órdenes pendientes. Última consulta correcta.";
                    JSONObject command = root.getJSONObject("command");
                    String commandId = command.optString("id", "");
                    String action = command.optString("action", "");
                    String reason = command.optString("reason", "Orden del administrador");
                    if (commandId.isEmpty()) return "Orden remota inválida; no se ejecutó.";
                    if ("LOCK".equals(action)) {
                        RedLineManager.activate(app, "Bloqueo remoto: " + reason);
                        RedLineAudit.record(app, "REMOTE_LOCK_RECEIVED", commandId);
                        acknowledge(base, token, device, commandId, "APPLIED");
                        return "RED LINE activado por orden remota dentro de la aplicación.";
                    }
                    if ("UNLOCK".equals(action)) {
                        RedLineAudit.record(app, "REMOTE_UNLOCK_REQUESTED", commandId);
                        acknowledge(base, token, device, commandId, "LOCAL_PIN_REQUIRED");
                        return "Solicitud recibida. Por seguridad, introduce el PIN local en RED LINE.";
                    }
                    acknowledge(base, token, device, commandId, "REJECTED_UNKNOWN_ACTION");
                    return "Orden desconocida rechazada.";
                } catch (Exception e) {
                    return "Error de sincronización: " + e.getClass().getSimpleName();
                } finally { if (connection != null) connection.disconnect(); }
            }
            protected void onPostExecute(String message) {
                boolean success = message.startsWith("Sin órdenes") ||
                        message.startsWith("RED LINE activado") || message.startsWith("Solicitud recibida");
                callback.done(message, success);
            }
        }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
    }

    private static void acknowledge(String base, String token, String device, String commandId, String result) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(base + "/device/ack").openConnection();
            c.setInstanceFollowRedirects(false);
            c.setRequestMethod("POST");
            c.setConnectTimeout(8000); c.setReadTimeout(8000); c.setDoOutput(true);
            c.setRequestProperty("Authorization", "Bearer " + token);
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            JSONObject payload = new JSONObject();
            payload.put("deviceId", device); payload.put("commandId", commandId); payload.put("result", result);
            OutputStream out = c.getOutputStream();
            out.write(payload.toString().getBytes(Charset.forName("UTF-8")));
            out.close();
            c.getResponseCode();
        } catch (Exception ignored) { /* backend status will show missing acknowledgement */ }
        finally { if (c != null) c.disconnect(); }
    }

    private static String trim(String value) {
        if (value == null) return "";
        String s = value.trim();
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }
    private static String readBody(InputStream in) throws Exception {
        if (in == null) return "";
        BufferedReader reader = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        StringBuilder body = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) body.append(line);
        reader.close();
        return body.toString();
    }
}
