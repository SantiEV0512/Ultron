package com.dawncore.aiphone;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Visible in-app emergency screen. It intentionally does not claim to lock Android itself. */
public class RedLineActivity extends Activity {
    private EditText pin;
    private TextView hint;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setStatusBarColor(Color.rgb(17,16,34));
        getWindow().setNavigationBarColor(Color.rgb(17,16,34));
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER_HORIZONTAL); root.setPadding(22,28,22,12); root.setBackgroundColor(Color.rgb(17,16,34));
        TextView mark = text("╱   ╱   ╱   ╱", 42, Color.WHITE, true); mark.setLetterSpacing(0.08f); root.addView(mark);
        TextView name = text("D A W N C O R E", 22, Color.WHITE, true); name.setPadding(0,0,0,38); root.addView(name);
        TextView lock = text("●", 54, 0xffef4b41, true); root.addView(lock);
        TextView heading = text("Dispositivo bloqueado", 24, Color.WHITE, true); heading.setPadding(0,14,0,14); root.addView(heading);
        TextView message = text("El administrador ha bloqueado este dispositivo.", 16, Color.WHITE, false); message.setGravity(Gravity.CENTER); root.addView(message);
        TextView why = text("RED LINE: " + RedLineManager.reason(this), 12, 0xffc5c4d0, false); why.setGravity(Gravity.CENTER); why.setPadding(0,16,0,12); root.addView(why);
        TextView time = text("Activado: " + new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(new Date(RedLineManager.lockedAt(this))), 11, 0xff9291a4, false); root.addView(time);
        pin = new EditText(this); pin.setSingleLine(true); pin.setGravity(Gravity.CENTER); pin.setTextColor(Color.WHITE); pin.setHintTextColor(0xffaaa8bb); pin.setHint("PIN administrador (6–8 dígitos)"); pin.setInputType(2); root.addView(pin, new LinearLayout.LayoutParams(-1,-2));
        hint = text("El PIN tiene protección contra intentos repetidos.", 11, 0xffaaa8bb, false); root.addView(hint);
        Button unlock = new Button(this); unlock.setText("DESBLOQUEAR"); unlock.setOnClickListener(v -> attemptUnlock()); root.addView(unlock);
        TextView protocol = text("EJECUTANDO PROTOCOLO \"RED LINE\"", 13, Color.WHITE, true); protocol.setGravity(Gravity.CENTER); LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1,0,1); pp.topMargin=18; root.addView(protocol,pp);
        TextView bar = new TextView(this); bar.setHeight(12); GradientDrawable gradient = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xffff241e,0xffff7a00,0xffffdf00,0xff00a7ff}); bar.setBackground(gradient); root.addView(bar,new LinearLayout.LayoutParams(-1,12));
        setContentView(root);
        updateCooldown();
    }
    private void attemptUnlock() {
        if (System.currentTimeMillis() < RedLineManager.pinBlockedUntil(this)) { updateCooldown(); return; }
        if (RedLineManager.unlock(this, pin.getText().toString())) { finish(); return; }
        pin.setText(""); updateCooldown();
        new AlertDialog.Builder(this).setTitle("PIN incorrecto").setMessage("No se pudo verificar el PIN. Revisa los dígitos e inténtalo de nuevo cuando termine la espera de seguridad.").setPositiveButton("Entendido", null).show();
    }
    private void updateCooldown(){long left=RedLineManager.pinBlockedUntil(this)-System.currentTimeMillis();if(left>0)hint.setText("Espera "+((left+999)/1000)+" segundos antes de volver a intentarlo.");else hint.setText("Intentos fallidos: "+RedLineManager.pinFailures(this)+". La espera aumenta progresivamente.");}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER);if(bold)t.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));return t;}
    @Override public void onBackPressed() { /* App-level screen only; Android system navigation is not device-owner locked. */ }
}
