package com.dawncore.aiphone;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

/** Bounded local diagnostic log. This is not a tamper-proof forensic log. */
public final class RedLineAudit {
    private static final String PREFS = "dawncore_redline_audit";
    private static final int MAX_EVENTS = 100;
    private RedLineAudit() {}
    public static synchronized void record(Context c, String event, String detail) {
        try {
            SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            JSONArray old = new JSONArray(p.getString("events", "[]"));
            JSONArray next = new JSONArray();
            int start = Math.max(0, old.length() - MAX_EVENTS + 1);
            for (int i = start; i < old.length(); i++) next.put(old.get(i));
            JSONObject item = new JSONObject();
            item.put("time", System.currentTimeMillis()); item.put("event", event);
            item.put("detail", detail == null ? "" : detail.substring(0, Math.min(180, detail.length())));
            next.put(item);
            p.edit().putString("events", next.toString()).commit();
        } catch (Exception ignored) { }
    }
    public static String exportText(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("events", "[]");
    }
}
