package com.dawncore.aiphone;
public class ActionPlan {
 public enum Type { CALL, WHATSAPP, EMAIL, UNKNOWN }
 public final Type type; public final String alias,message,subject,body;
 public ActionPlan(Type t,String a,String m,String s,String b){type=t;alias=a==null?"":a.trim().toLowerCase();message=m==null?"":m;subject=s==null?"":s;body=b==null?"":b;}
 public String describe(ContactEntry c){if(type==Type.CALL)return "Llamar a "+c.alias+" ("+c.phone+")";if(type==Type.WHATSAPP)return "WhatsApp a "+c.alias+":\n"+message;if(type==Type.EMAIL)return "Correo a "+c.alias+" <"+c.email+">\nAsunto: "+subject+"\n\n"+body;return "Acción desconocida";}
}
