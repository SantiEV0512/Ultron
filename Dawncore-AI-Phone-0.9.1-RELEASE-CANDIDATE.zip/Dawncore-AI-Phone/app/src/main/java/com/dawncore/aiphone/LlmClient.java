package com.dawncore.aiphone;

import android.content.Context;
import org.json.JSONObject;

/** Groq is reached only through the authenticated Cloudflare Worker. */
public final class LlmClient {
    public interface Callback { void done(ActionPlan plan, String error); }
    private LlmClient() {}

    public static void interpret(Context context, String command, Callback callback) {
        try {
            JSONObject payload = new JSONObject();
            payload.put("prompt", command);
            CloudAssistantClient.send(context, "/assistant/llm", payload, (ok, result) -> {
                if (!ok) { callback.done(null, result); return; }
                try {
                    int start = result.indexOf('{'), end = result.lastIndexOf('}');
                    if (start < 0 || end <= start) throw new IllegalArgumentException("JSON no válido");
                    JSONObject json = new JSONObject(result.substring(start, end + 1));
                    String action = json.optString("action", "unknown");
                    ActionPlan.Type type = "call".equals(action) ? ActionPlan.Type.CALL :
                            "whatsapp".equals(action) ? ActionPlan.Type.WHATSAPP :
                            "email".equals(action) ? ActionPlan.Type.EMAIL : ActionPlan.Type.UNKNOWN;
                    callback.done(new ActionPlan(type, json.optString("alias"), json.optString("message"),
                            json.optString("subject"), json.optString("body")), null);
                } catch (Exception e) { callback.done(null, "Respuesta del modelo inválida: " + e.getMessage()); }
            });
        } catch (Exception e) { callback.done(null, e.getMessage()); }
    }
}
