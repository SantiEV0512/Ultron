package com.dawncore.aiphone;
import android.app.Notification;import android.os.Bundle;import android.service.notification.NotificationListenerService;import android.service.notification.StatusBarNotification;
public class NotificationCaptureService extends NotificationListenerService {
 @Override public void onNotificationPosted(StatusBarNotification s){if(s==null||s.getNotification()==null)return;String p=s.getPackageName();if(p==null||!(p.equals("com.whatsapp")||p.equals("com.google.android.gm")||p.toLowerCase().contains("email")))return;Bundle b=s.getNotification().extras;if(b==null)return;CharSequence t=b.getCharSequence(Notification.EXTRA_TITLE),x=b.getCharSequence(Notification.EXTRA_BIG_TEXT);if(x==null)x=b.getCharSequence(Notification.EXTRA_TEXT);getSharedPreferences("dawncore_notifications",0).edit().putString("package",p).putString("title",t==null?"":t.toString()).putString("text",x==null?"":x.toString()).apply();}
}
