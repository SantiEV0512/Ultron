package com.dawncore.aiphone;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import java.util.Locale;

/** Offline Android TTS fallback when the Fish Audio cloud voice is unavailable. */
public final class UltronVoice implements TextToSpeech.OnInitListener {
    public interface ReadyCallback { void onReady(boolean ready); }
    private TextToSpeech tts;
    private boolean ready = false;
    private ReadyCallback callback;

    public UltronVoice(Context context, ReadyCallback callback) {
        this.callback = callback;
        tts = new TextToSpeech(context.getApplicationContext(), this);
    }

    @Override public void onInit(int status) {
        ready = status == TextToSpeech.SUCCESS;
        if (ready) {
            int result = tts.setLanguage(new Locale("es", "MX"));
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                result = tts.setLanguage(new Locale("es"));
            }
            ready = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED;
            if (ready) { tts.setSpeechRate(0.94f); tts.setPitch(0.82f); }
        }
        if (callback != null) callback.onReady(ready);
    }

    public boolean isReady() { return ready; }
    public void speak(String text) {
        if (!ready || text == null || text.trim().isEmpty()) return;
        if (android.os.Build.VERSION.SDK_INT >= 21) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ultron-voice");
        else tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }
    public void stop() { if (tts != null) tts.stop(); }
    public void shutdown() { if (tts != null) { tts.stop(); tts.shutdown(); tts = null; } ready = false; }
}
