package com.dawncore.aiphone;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * ULTRON Evolution Lab. Stores local observations and human-review proposals only.
 * This class deliberately has no shell, reflection, dynamic loading, package install,
 * source-code mutation, policy editing, or RED LINE credential API.
 */
public final class EvolutionEngine {
    private static final String PREFS = "ultron_evolution";
    private static final int MAX_ITEMS = 40;
    private EvolutionEngine() {}

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static synchronized void remember(Context c, String observation) {
        String value = clean(observation, 240);
        if (value.isEmpty()) return;
        JSONArray a = read(c, "observations");
        JSONObject item = new JSONObject();
        try {
            item.put("text", value);
            item.put("createdAt", System.currentTimeMillis());
            a.put(item);
        } catch (Exception ignored) { return; }
        trim(a);
        prefs(c).edit().putString("observations", a.toString()).commit();
        RedLineAudit.record(c, "EVOLUTION_OBSERVATION", "Observación local registrada");
    }

    public static synchronized void propose(Context c, String title, String detail) {
        String t = clean(title, 100), d = clean(detail, 500);
        if (t.isEmpty() || d.isEmpty()) throw new IllegalArgumentException("Escribe un título y una descripción.");
        JSONArray a = read(c, "proposals");
        JSONObject item = new JSONObject();
        try {
            item.put("id", "EV-" + java.util.UUID.randomUUID().toString());
            item.put("title", t);
            item.put("detail", d);
            item.put("status", "PENDING_REVIEW");
            item.put("createdAt", System.currentTimeMillis());
            item.put("safety", "NO EJECUTABLE: requiere revisión y autorización humana");
            a.put(item);
        } catch (Exception ignored) { throw new IllegalStateException("No se pudo crear la propuesta."); }
        trim(a);
        if (!prefs(c).edit().putString("proposals", a.toString()).commit())
            throw new IllegalStateException("No se pudo guardar la propuesta.");
        RedLineAudit.record(c, "EVOLUTION_PROPOSAL", t);
    }

    public static synchronized String report(Context c) {
        JSONArray obs = read(c, "observations"), props = read(c, "proposals");
        StringBuilder b = new StringBuilder();
        b.append("Observaciones locales: ").append(obs.length());
        b.append("\nPropuestas registradas: ").append(props.length());
        for (int i = props.length() - 1; i >= 0; i--) {
            JSONObject o = props.optJSONObject(i);
            if (o == null) continue;
            b.append("\n\n").append(o.optString("title"));
            b.append("\nEstado: ").append(o.optString("status"));
            b.append("\n").append(o.optString("detail"));
        }
        b.append("\n\nLímite de seguridad: no ejecuta código ni modifica RED LINE, PIN, permisos o archivos de la app.");
        return b.toString();
    }

    private static JSONArray read(Context c, String key) {
        try { return new JSONArray(prefs(c).getString(key, "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }
    private static void trim(JSONArray a) {
        while (a.length() > MAX_ITEMS) a.remove(0);
    }
    private static String clean(String s, int max) {
        if (s == null) return "";
        String v = s.replace('\u0000', ' ').trim();
        return v.length() > max ? v.substring(0, max) : v;
    }
}
