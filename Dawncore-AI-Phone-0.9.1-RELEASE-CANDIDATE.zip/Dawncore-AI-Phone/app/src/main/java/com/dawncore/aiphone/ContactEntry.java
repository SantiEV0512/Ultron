package com.dawncore.aiphone;
import org.json.JSONException; import org.json.JSONObject; import java.util.Locale;
public class ContactEntry {
 public final String alias, phone, email;
 public ContactEntry(String a,String p,String e){alias=a==null?"":a.trim().toLowerCase();phone=p==null?"":p.replaceAll("[^0-9]","");email=e==null?"":e.trim().toLowerCase(Locale.ROOT);}
 public JSONObject json() throws JSONException {JSONObject o=new JSONObject();o.put("alias",alias);o.put("phone",phone);o.put("email",email);return o;}
 public static ContactEntry from(JSONObject o){return new ContactEntry(o.optString("alias"),o.optString("phone"),o.optString("email"));}
 public String toString(){return alias+" · "+(phone.isEmpty()?"sin teléfono":phone)+(email.isEmpty()?"":" · "+email);}
}
